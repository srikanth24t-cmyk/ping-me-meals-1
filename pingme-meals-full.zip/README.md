# Ping Me Meals

Full-featured, Render-optimized repo for Ping Me Meals — Express backend + React frontend + Twilio WhatsApp confirmations.

Follow render-services.md or use the Render Blueprint (render.yaml). See .env.example for required env variables.
